'use strict';

$(document).ready(function() {
		var imgSource = [];
		var likeSource = [];
        var nextNote = ["https://graph.facebook.com/v1.0/302196939943133/photos?pretty=1&fields=source&limit=100&before=MzIyNDI1NDE0NTg2OTUy/photos_stream?tab=photos_stream"];
        var rand = 0;
        var showImgSrc = '';
        var pointer = 0;
        window.localStorage["like"];

        $('#dislike').on('click', function(){
            $('#alert-msg').fadeOut();
            if((likeSource.length !== 0) && (imgSource.length == 0)) {
                likeSource.splice(rand, 1);
                localStorage["like"] = JSON.stringify(likeSource); 
            } else {
                imgSource.splice(rand, 1);
            }
    	    if(imgSource.length > 10) {
    	    	rand = Math.floor(Math.random() * imgSource.length);
            	showImgSrc = imgSource[rand];
	            $('#show-img-area').attr('href', showImgSrc);
            	$('#show-img-area').html('<img src="' + showImgSrc + '">');
        	} else {
                loadPhoto();
            }
        });
        $('#like').on('click', function(){
        	savePhoto();
        });

        function init() {
        	console.log('init');
            //JSON.parse(localStorage["like"]).length
        	if(typeof localStorage.like !== 'undefined') {
        		likeSource = JSON.parse(localStorage["like"]);
                rand = Math.floor(Math.random() * likeSource.length);
                showImgSrc = likeSource[rand];
                $('#show-img-area').attr('href', showImgSrc);
                $('#show-img-area').html('<img src="' + showImgSrc + '">');         
            } else {
                loadPhoto();
            }
        }

        function savePhoto() {
        	if((likeSource.indexOf(showImgSrc) === -1)) {
	 			likeSource.push(showImgSrc); 
				localStorage["like"] = JSON.stringify(likeSource); 
				console.log('收藏');
                $('#alert-msg').html('<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>收藏 <strong>Beauty</strong> 成功！</div>').fadeIn();
        	} else {
                $('#alert-msg').html('<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>您已經收藏過啦XD </div>').fadeIn();
        	}
        }

        function loadPhoto() {
	       	$.ajax({
	            type: 'GET',
	            dataType: 'json',
	            url: nextNote[pointer],
	            success: function(res) {
	            	for(var key in res.data) {
	            		imgSource.push(res.data[key].source);
	            	}
	            	nextNote.push(res.paging.next);
	            	rand = Math.floor(Math.random() * imgSource.length);
                    if(likeSource.length !== 0)
                        imgSource = imgSource.concat(likeSource);
	            	showImgSrc = imgSource[rand];
	            	if(imgSource.length !== 0) {
	            		$('#show-img-area').attr('href', showImgSrc);
		            	$('#show-img-area').html('<img src="' + showImgSrc + '" >');
	            	}
	            	pointer++;
	            },
	            error: function(e){
	            	$('#show-img-area').html('<img src="' + showImgSrc + '">');
	            }

	        });
        }
        Array.prototype.unique = function() {
            var a = this.concat();
            for(var i=0; i<a.length; ++i) {
                for(var j=i+1; j<a.length; ++j) {
                    if(a[i] === a[j])
                        a.splice(j--, 1);
                }
            }
            return a;
        };
        init();
});